package com.ALL_in_one.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {


    private String token;


    private Long userId;


    private String fullName;


    private String email;


    private String role;

}